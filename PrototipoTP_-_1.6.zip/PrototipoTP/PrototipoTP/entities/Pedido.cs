﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.entities
{
    class Pedido
    {
        public Pedido() { }
        public int ID { get; set; }
        public String Descripcion { get; set; }
        public int MontoTotal { get; set; }
        public List<DetallePedido> DetallesPedidos { get; set; }
    }
}
