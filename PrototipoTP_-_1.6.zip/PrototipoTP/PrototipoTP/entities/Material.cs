﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.entities
{
    class Material
    {
        public Material() { }
        public int ID {get; set;}
        public String Nombre {get; set;}
        public String Color {get; set;}
        public int Stock {get; set;}
    }
}
