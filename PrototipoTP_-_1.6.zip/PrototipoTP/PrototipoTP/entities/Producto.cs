﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.entities
{
    class Producto
    {
        public Producto() { }
        public int ID {get; set;}
        public String Nombre {get; set;}
        public int Stock {get; set;}
        public String Material {get; set;}
        public double PrecioUnitario {get; set;}



    }
}
