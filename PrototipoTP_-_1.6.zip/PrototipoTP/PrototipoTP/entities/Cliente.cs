﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.entities
{
    class Cliente
    {
        public Cliente() { }
        public int ID { get; set; }
        public String Nombre { get; set; }
        public String Apellido { get; set; }
        public String DNI { get; set; }
        public String Numero { get; set; }
        public List<Pedido> Pedidos { get; set; }
    }
}
