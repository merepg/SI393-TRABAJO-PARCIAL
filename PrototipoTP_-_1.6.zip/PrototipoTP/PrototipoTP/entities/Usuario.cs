﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.entities
{
    class Usuario
    {
        public Usuario() { }
        public int ID { get; set; } 
        public String Nombre { get; set; }
        public String Apellido { get; set; }
        public String Rol { get; set; }
        public String Username { get; set; }
        public String Contrasenia { get; set; }
        public String Correo { get; set; }
    }
}
