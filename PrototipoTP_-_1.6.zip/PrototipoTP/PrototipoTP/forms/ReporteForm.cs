﻿using PrototipoTP.entities;
using PrototipoTP.services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoTP
{
    public partial class ReporteForm : Form
    {
        private ClienteService clienteService = new ClienteService();
        private ProductoService productoService = new ProductoService();
        private MaterialService materialService = new MaterialService();
        private PedidoService pedidoService = new PedidoService();
        private DetallePedidoService detallePedidoService = new DetallePedidoService();
        public ReporteForm()
        {
            InitializeComponent();
        }
        private void MostrarMateriales(List<Material> materiales)
        {
            dgMateriales.DataSource = null;
            if (materiales.Count == 0)
            {
                return;
            }
            else
            {
                dgMateriales.DataSource = materiales;
            }
        }
        private void MostrarProductos(List<Producto> productos)
        {
            dgProductos.DataSource = null;
            if (productos.Count == 0)
            {
                return;
            }
            else
            {
                dgProductos.DataSource = productos;
            }
        }

        private void MostrarPedidos(List<Pedido> pedidos)
        {
            dgPedidos.DataSource = null;
            if (pedidos.Count == 0)
            {
                return;
            }
            else
            {
                dgPedidos.DataSource = pedidos;
            }
        }
        private void MostrarClientes(List<Cliente> clientees)
        {
            dgClientes.DataSource = null;
            if (clientees.Count == 0)
            {
                return;
            }
            else
            {
                dgClientes.DataSource = clientees;
            }
        }

        private void MostrarDetallePedido(List<DetallePedido> detallePedidos)
        {
            dgProductos.DataSource = null;
            if (detallePedidos.Count == 0)
            {
                return;
            }
            else
            {
                dgProductos.DataSource = detallePedidos;
            }
        }

        private void btnMaterialesBajoStock_Click(object sender, EventArgs e)
        {
            MostrarMateriales(materialService.ListarPorBajoStock());
        }

        private void btnProductosBajoStock_Click(object sender, EventArgs e)
        {
            MostrarProductos(productoService.ListarPorBajoStock());
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tbID_Cliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

        private void btnClientesMasHabituales_Click(object sender, EventArgs e)
        {
            MostrarClientes(clienteService.ListarClientesConMasPedidos());
        }

        private void btnVerPedidosMasGrandes_Click(object sender, EventArgs e)
        {
            MostrarPedidos(pedidoService.ListarPedidosConMayorMontoTotal());
        }

        private void btnProductosMasVendidos_Click(object sender, EventArgs e)
        {
            MostrarDetallePedido(detallePedidoService.ListarMasVendidos());
        }
    }
}
