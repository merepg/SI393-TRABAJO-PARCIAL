﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoTP
{
    public partial class PrincipalForm : Form
    {
        public PrincipalForm()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if (tbUser.Text == "" || tbPassword.Text == "")
            {
                MessageBox.Show("Ingrese sus credenciales para continuar");
                return;
            }
            if (tbUser.Text != "admin" || tbPassword.Text != "admin")
            {
                MessageBox.Show("Usuario no encontrado\nVerifique sus credenciales de acceso");
                return;
            }

            MenuForm menuForm = new MenuForm();
            menuForm.ShowDialog();            
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
