﻿using PrototipoTP.entities;
using PrototipoTP.services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoTP
{
    public partial class PedidoForm : Form
    {
        private PedidoService pedidoService = new PedidoService();
        private int idCliente;
        public PedidoForm(int idCliente)
        {
            InitializeComponent();
            this.idCliente = idCliente;
            MostrarPedidos(pedidoService.ListarTodo(idCliente));
        }
        private void MostrarPedidos(List<Pedido> pedidos)
        {
            dgPedidos.DataSource = null;
            if (pedidos.Count == 0)
            {
                return;
            }
            else
            {
                dgPedidos.DataSource = pedidos;
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (tbID.Text.Trim() == "" || rtbDescripcion.Text.Trim() == "")
            {
                MessageBox.Show("Complete los campos.");
                return;
            }

            Pedido pedido = new Pedido()
            {
                ID = int.Parse(tbID.Text),
                Descripcion = rtbDescripcion.Text,
                MontoTotal = 1500,
                DetallesPedidos = new List<DetallePedido>(),
            };

            bool registrado = pedidoService.Registrar(idCliente, pedido);
            if (!registrado)
            {
                MessageBox.Show("ID de pedido ya registrado");
                return;
            }

            MostrarPedidos(pedidoService.ListarTodo(idCliente));
            lbCreatedBy.Text = "admin";
            lbCreateDate.Text = (DateTime.Now).ToString();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnVerDetallePedido_Click(object sender, EventArgs e)
        {
            if (dgPedidos.SelectedRows.Count == 0)
            {
                return;
            }
            int id_Pedido = int.Parse(dgPedidos.SelectedRows[0].Cells[0].Value.ToString());

            DetallePedidoForm form = new DetallePedidoForm(id_Pedido, idCliente);
            form.Show();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgPedidos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione el pedido a eliminar");
                return;
            }

            int ID_ParaEliminar = int.Parse(dgPedidos.SelectedRows[0].Cells[0].Value.ToString());
            pedidoService.Eliminar(ID_ParaEliminar);

            MostrarPedidos(pedidoService.ListarTodo(idCliente));
            lbUpdatedBy.Text = "admin";
            lbUpdateDate.Text = (DateTime.Now).ToString();
        }

        private void tbID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

    }
}
