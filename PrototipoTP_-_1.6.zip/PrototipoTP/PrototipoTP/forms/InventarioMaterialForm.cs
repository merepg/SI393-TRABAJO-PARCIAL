﻿using PrototipoTP.entities;
using PrototipoTP.services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoTP
{
    public partial class InventarioMaterialForm : Form
    {
        private MaterialService materialService = new MaterialService();  
        public InventarioMaterialForm()
        {
            InitializeComponent();
            MostrarMateriales(materialService.ListarTodo());
        }
        private void MostrarMateriales(List<Material> materiales)
        {
            dgMateriales.DataSource = null;
            if (materiales.Count == 0)
            {
                return;
            }
            else
            {
                dgMateriales.DataSource = materiales;
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (tbID.Text == "" || tbNombre.Text == "" || tbColor.Text == "" || tbStock.Text == "")
            {
                MessageBox.Show("Rellene todos los campos para registrar");
                return;
            }

            Material material = new Material()
            {
                ID = int.Parse(tbID.Text),
                Nombre = tbNombre.Text,
                Color = tbColor.Text,
                Stock = int.Parse(tbStock.Text)
            };

            bool existe = materialService.Registrar(material);
            if (!existe)
            {
                MessageBox.Show("ID ya existente, ingrese uno diferente");
                return;
            }

            MostrarMateriales(materialService.ListarTodo());

            lbCreatedBy.Text = "admin";
            lbCreateDate.Text = (DateTime.Now).ToString();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgMateriales.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un material a eliminar");
                return;
            }

            int ID_ParaEliminar = int.Parse(dgMateriales.SelectedRows[0].Cells[0].Value.ToString());
            materialService.Eliminar(ID_ParaEliminar);

            MostrarMateriales(materialService.ListarTodo());
      
        }

        private void btnAumentarStock_Click(object sender, EventArgs e)
        {
            if (dgMateriales.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un material para aumentar su stock");
                return;
            }

            int StockAumento = int.Parse(tbModStock.Text);
            int ID_ParaAumento = int.Parse(dgMateriales.SelectedRows[0].Cells[0].Value.ToString());
            materialService.AumentarStock(ID_ParaAumento, StockAumento);
            
            MostrarMateriales(materialService.ListarTodo());

            lbUpdatedBy.Text = "admin";
            lbUpdateDate.Text = (DateTime.Now).ToString();
        }

        private void btnRestarStock_Click(object sender, EventArgs e)
        {
            if (dgMateriales.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un material para disminuir su stock");
                return;
            }

            int StockDisminuir = int.Parse(tbModStock.Text);
            int ID_ParaDisminuir = int.Parse(dgMateriales.SelectedRows[0].Cells[0].Value.ToString());
            materialService.DisminuirStock(ID_ParaDisminuir, StockDisminuir);

            MostrarMateriales(materialService.ListarTodo());

            lbUpdatedBy.Text = "admin";
            lbUpdateDate.Text = (DateTime.Now).ToString();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tbID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

        private void tbStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

        private void tbModStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

        private void dgMateriales_SelectionChanged(object sender, EventArgs e)
        {
            lbCreatedBy.Text = "admin";
            lbCreateDate.Text = "14-05-2024";
        }
    }
}
