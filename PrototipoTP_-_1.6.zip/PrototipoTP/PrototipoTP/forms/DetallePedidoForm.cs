﻿using PrototipoTP.entities;
using PrototipoTP.services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoTP
{
    public partial class DetallePedidoForm : Form
    {
        DetallePedidoService detallePedidoService = new DetallePedidoService();
        int idPedido;
        int idCliente;

        public DetallePedidoForm(int idPedido, int idCliente)
        {
            InitializeComponent();
            this.idPedido = idPedido;
            this.idCliente = idCliente;
            MostrarDetallePedido(detallePedidoService.ListarTodo(idPedido, idCliente));
        }
        private void MostrarDetallePedido(List<DetallePedido> detallePedidos)
        {
            dgDetallePedidos.DataSource = null;
            if (detallePedidos.Count == 0)
            {
                return;
            }
            else
            {
                dgDetallePedidos.DataSource = detallePedidos;
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (tbIDProducto.Text.Trim() == "" || tbCantidad.Text.Trim() == "")
            {
                MessageBox.Show("Complete los campos.");
                return;
            }

            DetallePedido detallePedido = new DetallePedido()
            {
                IDProducto = int.Parse(tbIDProducto.Text),
                Cantidad = int.Parse(tbCantidad.Text),
                TotalPrecioProducto = 500,
            };

            bool registrado = detallePedidoService.Registrar(idPedido, detallePedido, idCliente);
            if (!registrado)
            {
                MessageBox.Show("ID de pedido ya registrado");
                return;
            }

            MostrarDetallePedido(detallePedidoService.ListarTodo(idPedido, idCliente));

            lbCreatedBy.Text = "admin";
            lbCreateDate.Text = (DateTime.Now).ToString();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgDetallePedidos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione el producto a eliminar");
                return;
            }

            int ID_ParaEliminar = int.Parse(dgDetallePedidos.SelectedRows[0].Cells[0].Value.ToString());
            detallePedidoService.Eliminar(ID_ParaEliminar, idCliente);

            MostrarDetallePedido(detallePedidoService.ListarTodo(idPedido, idCliente));
            lbUpdatedBy.Text = "admin";
            lbUpdateDate.Text = (DateTime.Now).ToString();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

    }
}
