﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoTP
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }

        private void btnGestionMateriales_Click(object sender, EventArgs e)
        {
            InventarioMaterialForm inventarioMaterialForm = new InventarioMaterialForm();
            inventarioMaterialForm.ShowDialog();
        }

        private void btnGestionProductos_Click(object sender, EventArgs e)
        {
            InventarioProductoForm inventarioProductoForm = new InventarioProductoForm();   
            inventarioProductoForm.ShowDialog();
        }

        private void btnGestionClientes_Click(object sender, EventArgs e)
        {
            ClienteForm clienteForm = new ClienteForm();
            clienteForm.ShowDialog();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            ReporteForm reporteForm = new ReporteForm();
            reporteForm.ShowDialog();
        }

        private void btnGestionUsuarios_Click(object sender, EventArgs e)
        {
            GestionUsuariosForm gestionUsuariosForm = new GestionUsuariosForm();
            gestionUsuariosForm.ShowDialog();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
