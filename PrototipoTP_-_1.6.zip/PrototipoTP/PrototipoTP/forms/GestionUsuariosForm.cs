﻿using PrototipoTP.entities;
using PrototipoTP.services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoTP
{
    public partial class GestionUsuariosForm : Form
    {
        private UsuarioService usuarioService = new UsuarioService();
        int contadorID = 0;
        public GestionUsuariosForm()
        {
            InitializeComponent();
            MostrarUsuarios(usuarioService.ListarTodo());
        }
        private void MostrarUsuarios(List<Usuario> usuarios)
        {
            dgUsuarios.DataSource = null;
            dgUsuarios2.DataSource = null;
            if (usuarios.Count == 0)
            {
                return;
            }
            else
            {
                dgUsuarios.DataSource = usuarios;
                dgUsuarios2.DataSource = usuarios;
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (tbApellidos.Text == "" || tbNombre.Text == "" || tbCorreo.Text == "" || tbUsername.Text == "" || tbContrasenia.Text == "" || cbRol.Text == "") 
            {
                MessageBox.Show("Rellene todos los campos para registrar");
                return;
            }

            contadorID++;
            Usuario usuario = new Usuario()
            {
                ID = contadorID,
                Nombre = tbNombre.Text,
                Apellido = tbApellidos.Text,
                Correo = tbCorreo.Text,
                Username = tbUsername.Text,
                Contrasenia = tbContrasenia.Text,
                Rol = cbRol.Text,
            };

            bool existe = usuarioService.Registrar(usuario);
            if (!existe)
            {
                MessageBox.Show("Username ocupado, ingrese uno diferente");
                contadorID--;
                return;
            }

            MostrarUsuarios(usuarioService.ListarTodo());

            lbCreatedBy.Text = "admin";
            lbCreateDate.Text = (DateTime.Now).ToString();
        }

        private void btnEliminarUsuario_Click(object sender, EventArgs e)
        {
            if (dgUsuarios2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un usuario a eliminar");
                return;
            }

            if (tbContraseniaAdmin.Text == "")
            {
                MessageBox.Show("Ingrese la contraseña del administrador");
                return;
            }

            if (tbContraseniaAdmin.Text != "admin")
            {
                MessageBox.Show("Contraseña incorrecta\nVerifique sus credenciales");
                return;
            }

            int ID_ParaEliminar = int.Parse(dgUsuarios2.SelectedRows[0].Cells[0].Value.ToString());
            usuarioService.Eliminar(ID_ParaEliminar);

            MostrarUsuarios(usuarioService.ListarTodo());

            lbUpdatedBy.Text = "admin";
            lbUpdateDate.Text = (DateTime.Now).ToString();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
