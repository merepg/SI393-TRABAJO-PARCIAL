﻿using PrototipoTP.entities;
using PrototipoTP.services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoTP
{
    public partial class ClienteForm : Form
    {
        private ClienteService clienteService = new ClienteService();
        public ClienteForm()
        {
            InitializeComponent();
            MostrarClientes(clienteService.ListarTodo());
        }
        private void MostrarClientes(List<Cliente> clientees)
        {
            dgClientes.DataSource = null;
            if (clientees.Count == 0)
            {
                return;
            }
            else
            {
                dgClientes.DataSource = clientees;
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (tbID.Text == "" || tbNombre.Text == "" || tbApellido.Text == "" || tbNumero.Text == "" || tbDNI.Text == "")
            {
                MessageBox.Show("Rellene todos los campos para registrar");
                return;
            }

            Cliente cliente = new Cliente()
            {
                ID = int.Parse(tbID.Text),
                Nombre = tbNombre.Text,
                Apellido = tbApellido.Text,
                Numero = tbNumero.Text,
                DNI = tbDNI.Text,
                Pedidos = new List<Pedido>(),
            };

            bool existe = clienteService.Registrar(cliente);
            if (!existe)
            {
                MessageBox.Show("ID/DNI ya existente, ingrese uno diferente");
                return;
            }

            MostrarClientes(clienteService.ListarTodo());

            lbCreatedBy.Text = "admin";
            lbCreateDate.Text = (DateTime.Now).ToString();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgClientes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un cliente a eliminar");
                return;
            }

            int ID_ParaEliminar = int.Parse(dgClientes.SelectedRows[0].Cells[0].Value.ToString());
            clienteService.Eliminar(ID_ParaEliminar);

            MostrarClientes(clienteService.ListarTodo());
            lbUpdatedBy.Text = "admin";
            lbUpdateDate.Text = (DateTime.Now).ToString();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnGestionarPedidos_Click(object sender, EventArgs e)
        {
            if (dgClientes.SelectedRows.Count == 0)
            {
                return;
            }
            int id = int.Parse(dgClientes.SelectedRows[0].Cells[0].Value.ToString());

            PedidoForm form = new PedidoForm(id);
            form.Show();
        }

        private void tbDNI_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

        private void tbID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

        private void tbNumero_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

    }
}
