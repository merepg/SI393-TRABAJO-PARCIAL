﻿using PrototipoTP.entities;
using PrototipoTP.services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoTP
{
    public partial class InventarioProductoForm : Form
    {
        private ProductoService productoService = new ProductoService();
        public InventarioProductoForm()
        {
            InitializeComponent();
            MostrarProductos(productoService.ListarTodo());
        }
        private void MostrarProductos(List<Producto> productos)
        {
            dgProductos.DataSource = null;
            if (productos.Count == 0)
            {
                return;
            }
            else
            {
                dgProductos.DataSource = productos;
            }
        }

        private void btnRegistro_Click(object sender, EventArgs e)
        {
            if (tbID.Text == "" || tbNombre.Text == "" || tbMaterial.Text == "" || tbStock.Text == "" || tbPrecioUnitario.Text == "")
            {
                MessageBox.Show("Rellene todos los campos para registrar");
                return;
            }

            Producto producto = new Producto()
            {
                ID = int.Parse(tbID.Text),
                Nombre = tbNombre.Text,
                Material = tbMaterial.Text,
                Stock = int.Parse(tbStock.Text),
                PrecioUnitario = double.Parse(tbPrecioUnitario.Text),
            };

            bool existe = productoService.Registrar(producto);
            if (!existe)
            {
                MessageBox.Show("ID ya existente, ingrese uno diferente");
                return;
            }

            MostrarProductos(productoService.ListarTodo());

            lbCreatedBy.Text = "admin";
            lbCreateDate.Text = (DateTime.Now).ToString();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgProductos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un producto a eliminar");
                return;
            }

            int ID_ParaEliminar = int.Parse(dgProductos.SelectedRows[0].Cells[0].Value.ToString());
            productoService.Eliminar(ID_ParaEliminar);

            MostrarProductos(productoService.ListarTodo());
        }

        private void btnAumentar_Click(object sender, EventArgs e)
        {
            if (dgProductos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un producto para aumentar su stock");
                return;
            }

            int StockAumento = int.Parse(tbModStock.Text);
            int ID_ParaAumento = int.Parse(dgProductos.SelectedRows[0].Cells[0].Value.ToString());
            productoService.AumentarStock(ID_ParaAumento, StockAumento);

            MostrarProductos(productoService.ListarTodo());

            lbUpdatedBy.Text = "admin";
            lbUpdateDate.Text = (DateTime.Now).ToString();
        }

        private void btnRestar_Click(object sender, EventArgs e)
        {
            if (dgProductos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un producto para disminuir su stock");
                return;
            }

            int StockDisminuir = int.Parse(tbModStock.Text);
            int ID_ParaDisminuir = int.Parse(dgProductos.SelectedRows[0].Cells[0].Value.ToString());
            productoService.DisminuirStock(ID_ParaDisminuir, StockDisminuir);

            MostrarProductos(productoService.ListarTodo());

            lbUpdatedBy.Text = "admin";
            lbUpdateDate.Text = (DateTime.Now).ToString();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tbID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

        private void tbStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

        private void tbPrecioUnitario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

        private void tbModStock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("¡Sólo valores númericos!");
                e.Handled = true;
                return;
            }
        }

    }
}
