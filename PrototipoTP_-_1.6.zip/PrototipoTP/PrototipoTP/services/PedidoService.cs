﻿using PrototipoTP.entities;
using PrototipoTP.repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.services
{
    class PedidoService
    {
        private PedidoRepository pedidoRepository = new PedidoRepository();
        public bool Registrar(int id, Pedido pedido)
        {
            if (pedidoRepository.Existe(pedido.ID))
            {
                return false;
            }
            else
            {
                pedidoRepository.Registrar(id, pedido);
                return true;
            }
        }
        public List<Pedido> ListarTodo(int id)
        {
            return pedidoRepository.ListarTodo(id);
        }
        public void Eliminar(int id)
        {
            pedidoRepository.Eliminar(id);
        }

        public List<Pedido> ListarPedidosConMayorMontoTotal()
        {
            return pedidoRepository.ListarPedidosConMayorMontoTotal();
        }
    }
}
