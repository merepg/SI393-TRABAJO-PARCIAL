﻿using PrototipoTP.entities;
using PrototipoTP.repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.services
{
    class MaterialService
    {
        private MaterialRepository materialRepository = new MaterialRepository();
        public bool Registrar(Material material)
        {
            if (materialRepository.Existe(material.ID))
            {
                return false;
            }
            else
            {
                materialRepository.Registrar(material);
                return true;
            }
        }
        public void Eliminar(int ID)
        {
            materialRepository.Eliminar(ID);
        }
        public void AumentarStock(int ID, int StockAumento)
        {
            materialRepository.AumentarStock(ID, StockAumento);
        }

        public void DisminuirStock(int ID, int StockDisminuye)
        {
           materialRepository.DisminuirStock(ID, StockDisminuye);
        }
        public List<Material> ListarPorBajoStock()
        {
            return materialRepository.ListarPorBajoStock();
        }
        public List<Material> ListarTodo()
        {
            return MaterialRepository.ListarTodo();
        }
    }
}
