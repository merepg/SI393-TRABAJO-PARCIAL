﻿using PrototipoTP.entities;
using PrototipoTP.repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.services
{
    class DetallePedidoService
    {
        private DetallePedidoRepository detallePedidoRepository = new DetallePedidoRepository();

        public bool Registrar (int idPedido, DetallePedido detallePedido, int idcliente)
        {
            if (detallePedidoRepository.Existe(detallePedido.IDProducto, idcliente, idPedido))
            {
                return false;
            }
            else
            {
                detallePedidoRepository.Registrar(idPedido, detallePedido, idcliente);
                return true;
            }
        }

        public List<DetallePedido> ListarTodo(int idPedido, int idCliente)
        {
            return detallePedidoRepository.ListarTodo(idPedido, idCliente);
        }

        public void Eliminar(int idParaEliminar, int idCliente)
        {
            detallePedidoRepository.Eliminar(idParaEliminar, idCliente);
        }

        public List<DetallePedido> ListarMasVendidos()
        {
            return detallePedidoRepository.ListarMasVendidos();
        }
    }
}
