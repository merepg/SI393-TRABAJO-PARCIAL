﻿using PrototipoTP.entities;
using PrototipoTP.repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.services
{
    class ClienteService
    {
        private ClienteRepository clienteRepository = new ClienteRepository();
        public bool Registrar(Cliente cliente)
        {
            if (clienteRepository.Existe(cliente.ID, cliente.DNI))
            {
                return false;
            }
            else
            {
                clienteRepository.Registrar(cliente);
                return true;
            }
        }
        public void Eliminar(int id)
        {
            clienteRepository.Eliminar(id);
        }

        public List<Cliente> ListarTodo()
        {
            return ClienteRepository.ListarTodo();
        }

        public List<Cliente> ListarClientesConMasPedidos()
        {
            return clienteRepository.ListarClientesConMasPedidos();
        }
    }
}
