﻿using PrototipoTP.entities;
using PrototipoTP.repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.services
{
    class UsuarioService
    {
        private UsuarioRepository usuarioRepository = new UsuarioRepository();
        public bool Registrar(Usuario usuario)
        {
            if (usuarioRepository.Existe(usuario.Username))
            {
                return false;
            }
            else
            {
                usuarioRepository.Registrar(usuario);
                return true;
            }
        }
        public void Eliminar(int ID)
        {
            usuarioRepository.Eliminar(ID);
        }
        public List<Usuario> ListarTodo()
        {
            return UsuarioRepository.ListarTodo();
        }
    }
}
