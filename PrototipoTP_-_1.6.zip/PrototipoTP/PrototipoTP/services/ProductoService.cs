﻿using PrototipoTP.entities;
using PrototipoTP.repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.services
{
    class ProductoService
    {
        private ProductoRepository productoRepository = new ProductoRepository();
        public bool Registrar(Producto producto)
        {
            if (productoRepository.Existe(producto.ID))
            {
                return false;
            }
            else
            {
                productoRepository.Registrar(producto);
                return true;
            }
        }
        public void Eliminar(int ID)
        {
            productoRepository.Eliminar(ID);
        }

        public void AumentarStock(int ID, int StockAumento)
        {
            productoRepository.AumentarStock(ID, StockAumento);
        }

        public void DisminuirStock(int ID, int StockDisminuye)
        {
            productoRepository.DisminuirStock(ID, StockDisminuye);
        }
        public List<Producto> ListarPorBajoStock()
        {
            return productoRepository.ListarPorBajoStock();
        }

        public List<Producto> ListarTodo()
        {
            return ProductoRepository.ListarTodo();
        }
    }
}
