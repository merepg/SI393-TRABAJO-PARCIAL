﻿using PrototipoTP.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.repositories
{
    class PedidoRepository
    {
        public bool Existe(int idPedido)
        {
            List<Cliente> clientes = ClienteRepository.ListarTodo();
            return clientes.Exists(c => c.Pedidos.Exists(p => p.ID.Equals(idPedido)));
        }

        public void Registrar(int idCliente, Pedido pedido)
        {
            List<Cliente> clientes = ClienteRepository.ListarTodo();
            Cliente cliente = clientes.Find(c => c.ID.Equals(idCliente));
            cliente.Pedidos.Add(pedido);
        }

        public List<Pedido> ListarTodo(int idCliente)
        {
            List<Cliente> clientes = ClienteRepository.ListarTodo();
            Cliente cliente = clientes.Find(c => c.ID.Equals(idCliente));
            return cliente.Pedidos;
        }
        public void Eliminar(int idParaEliminar)
        {
            List<Cliente> clientes = ClienteRepository.ListarTodo();

            foreach (Cliente cliente in clientes)
            {
                cliente.Pedidos.RemoveAll(p => p.ID.Equals(idParaEliminar));
            }
            
        }

        public List<Pedido> ListarPedidosConMayorMontoTotal()
        {
            List<Cliente> clientes = ClienteRepository.ListarTodo();
            List<Pedido> pedidosTemp = new List<Pedido>();
            int mayorMontoTotalGeneral = int.MinValue;
            foreach (Cliente cliente in clientes)
            {
                List<Pedido> pedidos = cliente.Pedidos;
                if (pedidos.Count != 0)
                {
                    foreach (Pedido pedido in pedidos)
                    {
                        int mayorMontoTotalDelPedido = pedidos.Max(p => p.MontoTotal);
                        if (mayorMontoTotalDelPedido > mayorMontoTotalGeneral)
                        {
                            mayorMontoTotalGeneral = mayorMontoTotalDelPedido;
                            pedidosTemp.Clear();
                            pedidosTemp.Add(pedido);
                        }
                        else if (mayorMontoTotalDelPedido == mayorMontoTotalGeneral)
                        {
                            pedidosTemp.Add(pedido);
                        }
                    }
                }
            }
                return pedidosTemp;
        }
    }
}
