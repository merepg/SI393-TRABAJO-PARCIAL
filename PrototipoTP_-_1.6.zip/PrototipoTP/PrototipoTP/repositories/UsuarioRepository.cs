﻿using PrototipoTP.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.repositories
{
    class UsuarioRepository
    {
        private static List<Usuario> usuarios = new List<Usuario>();

        public bool Existe(String username)
        {
            return usuarios.Exists(u => u.Username.Equals(username));
        }

        public void Registrar(Usuario usuario)
        {
            usuarios.Add(usuario);
        }

        public void Eliminar(int ID)
        {
            usuarios.RemoveAll(m => m.ID.Equals(ID));
        }

        public static List<Usuario> ListarTodo()
        {
            return usuarios;
        }
    }
}
