﻿using PrototipoTP.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.repositories
{
    class DetallePedidoRepository
    {
        private PedidoRepository pedidoRepository = new PedidoRepository();
        private static List<Cliente> clientes  = new List<Cliente>();

        public bool Existe(int idProducto, int idCliente, int idpedido)
        {
            List<Pedido> pedidos = pedidoRepository.ListarTodo(idCliente);
            Pedido pedido = pedidos.Find(p => p.ID.Equals(idpedido));
            return pedido.DetallesPedidos.Exists(d => d.IDProducto.Equals(idProducto));
        }

        public void Registrar(int idPedido, DetallePedido detallepedido, int idCliente)
        {
            List<Pedido> pedidos = pedidoRepository.ListarTodo(idCliente);
            Pedido pedido = pedidos.Find(p => p.ID.Equals(idPedido));
            pedido.DetallesPedidos.Add(detallepedido);
        }

        public List<DetallePedido> ListarTodo(int idPedido, int idCliente)
        {
            List<Pedido> pedidos = pedidoRepository.ListarTodo(idCliente);
            Pedido pedido = pedidos.Find(p => p.ID.Equals(idPedido));
            return pedido.DetallesPedidos;
        }

        public void Eliminar(int idParaEliminar, int idCliente)
        {
            List<Pedido> pedidos = pedidoRepository.ListarTodo(idCliente);

            foreach (Pedido pedido in pedidos)
            {
                pedido.DetallesPedidos.RemoveAll(dp => dp.IDProducto.Equals(idParaEliminar));
            }
        }
        public int SumaPedidosPorID(int ID_Producto)
        {
            List<Cliente> clientesList = ClienteRepository.ListarTodo();
            int sumaFinal = 0;

            foreach (Cliente cliente in clientesList)
            {
                foreach (Pedido pedido in cliente.Pedidos)
                {
                    foreach (DetallePedido detallePedido in pedido.DetallesPedidos)
                    {
                        if (detallePedido.IDProducto.Equals(ID_Producto))
                        {
                            sumaFinal += detallePedido.Cantidad;
                        }
                    }
                }
            }
            return sumaFinal;
        }
        public List<DetallePedido> ListarMasVendidos()
        {
            List<DetallePedido> detallePedidoTemp = new List<DetallePedido>();
            List<Cliente> clientesList = ClienteRepository.ListarTodo();

            int mayorCantidadProductos = 0;

            foreach (Cliente cliente in clientesList)
            {
                foreach (Pedido pedido in cliente.Pedidos)
                {
                    foreach (DetallePedido detallePedido in pedido.DetallesPedidos)
                    {
                        int SumaFinal = SumaPedidosPorID(detallePedido.IDProducto);

                        DetallePedido detallePedidoCopia = new DetallePedido
                        {
                            IDProducto = detallePedido.IDProducto,
                            Cantidad = SumaFinal,
                            TotalPrecioProducto = detallePedido.TotalPrecioProducto,
                        };

                        if (SumaFinal > mayorCantidadProductos)
                        {
                            mayorCantidadProductos = SumaFinal;
                            detallePedidoTemp.Clear();
                            detallePedidoTemp.Add(detallePedidoCopia);
                        }
                    }
                }
            }
            return detallePedidoTemp;
        }




    }
}
