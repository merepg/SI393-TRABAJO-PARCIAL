﻿using PrototipoTP.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.repositories
{
    class ClienteRepository
    {
        private static List<Cliente> clientes = new List<Cliente>();

        public bool Existe(int id, String dni)
        {
            return clientes.Exists(c => c.ID.Equals(id) || c.DNI.Equals(dni));
        }

        public void Registrar(Cliente cliente)
        {
            clientes.Add(cliente);
        }
        public void Eliminar(int id)
        {
            clientes.RemoveAll(m => m.ID.Equals(id));
        }

        public static List<Cliente> ListarTodo()
        {
            return clientes; 
        }

        public List<Cliente> ListarClientesConMasPedidos()
        {
            List<Cliente> clientesTemp = new List<Cliente>();
            int mayorCantidadPedidosTotal = int.MinValue;
            foreach (Cliente cliente in clientes)
            {
                List<Pedido> pedidos = cliente.Pedidos;
                int cantidadPedidosPorCliente = pedidos.Count;
                if (cantidadPedidosPorCliente > mayorCantidadPedidosTotal)
                {
                    mayorCantidadPedidosTotal = cantidadPedidosPorCliente;
                    clientesTemp.Clear();
                    clientesTemp.Add(cliente);
                }
                else if (cantidadPedidosPorCliente == mayorCantidadPedidosTotal)
                {
                    clientesTemp.Add(cliente);
                }
            }
            return clientesTemp;
        }
    }
}
