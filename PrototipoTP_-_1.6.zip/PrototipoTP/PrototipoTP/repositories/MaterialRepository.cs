﻿using PrototipoTP.entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.repositories
{
    class MaterialRepository
    {
        private static List<Material> materiales = new List<Material>();

        public bool Existe(int id)
        {
            return materiales.Exists(m => m.ID.Equals(id));
        }

        public void Registrar(Material material)
        {
            materiales.Add(material);
        }

        public void Eliminar(int ID)
        {
            materiales.RemoveAll(m => m.ID.Equals(ID));
        }

        public void AumentarStock(int ID, int StockAumento)
        {
            foreach(Material material in materiales)
            {
                if (material.ID.Equals(ID))
                {
                    material.Stock += StockAumento;
                }
            }
        }

        public void DisminuirStock(int ID, int StockDisminuye)
        {
            foreach (Material material in materiales)
            {
                if (material.ID.Equals(ID))
                {
                    if (StockDisminuye <= material.Stock)
                    {
                        material.Stock -= StockDisminuye;
                    }

                }
            }
        }

        public List<Material> ListarPorBajoStock()
        {
            List<Material> materialTemp = new List<Material>();
            int BajoStock = 10;

            foreach (Material material in materiales)
            {
                if (material.Stock <= BajoStock)
                {
                    materialTemp.Add(material);
                }
            }
            return materialTemp;
        }

        public static List<Material> ListarTodo()
        {
            return materiales;
        }
    }
}
