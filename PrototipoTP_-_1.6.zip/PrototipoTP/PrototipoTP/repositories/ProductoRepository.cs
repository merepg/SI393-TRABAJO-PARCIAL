﻿using PrototipoTP.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototipoTP.repositories
{
    class ProductoRepository
    {
        private static List<Producto> productos = new List<Producto>();

        public bool Existe(int id)
        {
            return productos.Exists(p => p.ID.Equals(id));
        }

        public void Registrar(Producto producto)
        {
            productos.Add(producto);
        }

        public void Eliminar(int ID)
        {
            productos.RemoveAll(m => m.ID.Equals(ID));
        }

        public void AumentarStock(int ID, int StockAumento)
        {
            foreach (Producto producto in productos)
            {
                if (producto.ID.Equals(ID))
                {
                    producto.Stock += StockAumento;
                }
            }
        }

        public void DisminuirStock(int ID, int StockDisminuye)
        {
            foreach (Producto producto in productos)
            {
                if (producto.ID.Equals(ID))
                {
                    if (StockDisminuye <= producto.Stock)
                    {
                        producto.Stock -= StockDisminuye;
                    }

                }
            }
        }
        public List<Producto> ListarPorBajoStock()
        {
            List<Producto> productoTemp = new List<Producto>();
            int BajoStock = 10;

            foreach (Producto producto in productos)
            {
                if (producto.Stock <= BajoStock)
                {
                    productoTemp.Add(producto);
                }
            }
            return productoTemp;
        }

        public static List<Producto> ListarTodo()
        {
            return productos;
        }
    }
}
